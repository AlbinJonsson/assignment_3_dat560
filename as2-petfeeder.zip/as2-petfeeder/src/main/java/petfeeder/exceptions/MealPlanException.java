package petfeeder.exceptions;

public class MealPlanException extends Exception {
    private static final long serialVersionUID = 1L;
    public MealPlanException(String msg) {
        super(msg);
    }
}
